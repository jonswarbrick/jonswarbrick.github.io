%  INTERNAL FUNCTION: Builds state matrices for the system
%  Aplus*X_{t+1}+A0*X_{t}+Aminus*X_{t-1}=0
%  the variables are ordered in the order_var order i.e.
%  [Stat.,Pred.,Both,Frwrd]
% 
%