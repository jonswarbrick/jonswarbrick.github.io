%  INTERNAL FUNCTION: doubling_solve solves the linear equation X=A*X*B+C using doubling algorithm
% 
%  ::
% 
%     [P,retcode]=doubling(A,B,C);
% 
%