%  low-level function
% 
%  No help provided
%