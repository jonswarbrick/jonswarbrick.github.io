%--- help for abstvar/residuals ---
%
%  Computes the residuals given the parameters
% 
%