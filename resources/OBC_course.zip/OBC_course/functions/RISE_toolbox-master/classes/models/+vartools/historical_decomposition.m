%--- help for abstvar/historical_decomposition ---
%
%  varargin={shock_names}
%
%    Other functions named historical_decomposition
%
%       dsge/historical_decomposition
%