%  INTERNAL FUNCTION: Choleski identification of structural shocks
% 
%