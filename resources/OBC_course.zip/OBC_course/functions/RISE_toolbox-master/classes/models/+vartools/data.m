%--- help for date ---
%
% DATE   Current date as character vector.
%    S = DATE returns a character vector containing the date in dd-mmm-yyyy format.
% 
%    See also NOW, CLOCK, DATENUM.
%
%    Reference page in Doc Center
%       doc date
%
%