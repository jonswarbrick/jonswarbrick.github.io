%--- help for encode_map ---
%
%  INTERNAL FUNCTION
% 
%