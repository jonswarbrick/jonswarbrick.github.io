%--- help for problist ---
%
%  INTERNAL FUNCTION
% 
%