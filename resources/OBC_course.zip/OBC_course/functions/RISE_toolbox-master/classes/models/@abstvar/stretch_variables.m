%--- help for stretch_variables ---
%
%  INTERNAL FUNCTION
% 
%