%--- help for map_estimation ---
%
%  INTERNAL FUNCTION
% 
%