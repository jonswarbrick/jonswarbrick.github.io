%--- help for format_transition_probabilities ---
%
%  INTERNAL FUNCTION
% 
%