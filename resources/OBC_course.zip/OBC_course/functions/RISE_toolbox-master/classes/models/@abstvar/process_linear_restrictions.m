%--- help for abstvar/process_linear_restrictions ---
%
%  INTERNAL FUNCTION
% 
%