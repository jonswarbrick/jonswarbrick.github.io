%--- help for abstvar/print_solution ---
%
%abstvar/print_solution is a function.
%    print_solution(obj, varlist)
%
%    Other functions named print_solution
%
%       dsge/print_solution
%