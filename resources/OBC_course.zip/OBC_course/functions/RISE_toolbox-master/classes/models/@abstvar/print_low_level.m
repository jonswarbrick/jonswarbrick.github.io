%--- help for print_low_level ---
%
%  INTERNAL FUNCTION
% 
%