%--- help for abstvar/collect_data ---
%
%  INTERNAL FUNCTION: Parse data into a useable format
% 
%  Note:
%     It is assumed that data is set in self.estim_.data before the execution of this function
% 
%