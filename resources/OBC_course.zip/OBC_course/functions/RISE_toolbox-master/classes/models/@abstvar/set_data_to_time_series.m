%--- help for abstvar/set_data_to_time_series ---
%
%  INTERNAL FUNCTION
% 
%