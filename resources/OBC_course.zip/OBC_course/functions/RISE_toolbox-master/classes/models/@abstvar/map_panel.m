%--- help for map_panel ---
%
%  INTERNAL FUNCTION
% 
%