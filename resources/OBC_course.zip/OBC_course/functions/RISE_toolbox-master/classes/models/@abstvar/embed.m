%--- help for embed ---
%
%  INTERNAL FUNCTION: Maps the data into proper lag/stacked form
% 
%