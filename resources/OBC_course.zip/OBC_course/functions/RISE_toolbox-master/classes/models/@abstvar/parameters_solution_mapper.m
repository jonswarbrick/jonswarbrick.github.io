%--- help for parameters_solution_mapper ---
%
%  INTERNAL FUNCTION
% 
%