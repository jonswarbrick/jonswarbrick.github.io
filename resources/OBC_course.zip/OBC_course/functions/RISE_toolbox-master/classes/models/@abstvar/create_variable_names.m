%--- help for create_variable_names ---
%
%  INTERNAL FUNCTION
% 
%