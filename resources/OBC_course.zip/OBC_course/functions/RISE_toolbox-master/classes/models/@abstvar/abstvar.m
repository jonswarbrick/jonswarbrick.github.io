%abstvar is a class.
%    self = abstvar(endog, exog, nlags, const, panel, markov_chains)
%
%    Reference page in Doc Center
%       doc abstvar
%
%