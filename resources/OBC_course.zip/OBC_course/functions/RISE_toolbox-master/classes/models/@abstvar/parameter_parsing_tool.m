%--- help for parameter_parsing_tool ---
%
%  INTERNAL FUNCTION
% 
%