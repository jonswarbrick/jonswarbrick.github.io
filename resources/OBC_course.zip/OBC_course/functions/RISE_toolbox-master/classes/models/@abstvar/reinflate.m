%--- help for reinflate ---
%
%  INTERNAL FUNCTION
% 
%