%--- help for reset_range ---
%
%  INTERNAL FUNCTION
% 
%