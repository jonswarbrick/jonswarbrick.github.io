%--- help for prime_time ---
%
%  INTERNAL FUNCTION: Sets panel related restrictions
% 
%