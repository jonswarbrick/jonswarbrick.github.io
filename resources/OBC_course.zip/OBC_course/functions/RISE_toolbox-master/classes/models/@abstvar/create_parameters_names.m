%--- help for create_parameters_names ---
%
%  INTERNAL FUNCTION
% 
%