%--- help for untransform ---
%
%  using the linres, untransform params before evaluating the
%  likelihood and later on the prior as well.
%