%--- help for recreate_parameters ---
%
%  INTERNAL FUNCTION
% 
%