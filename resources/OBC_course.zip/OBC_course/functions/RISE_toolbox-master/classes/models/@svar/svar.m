%svar is a class.
%    self = svar(varargin)
%
%    Reference page in Doc Center
%       doc svar
%
%