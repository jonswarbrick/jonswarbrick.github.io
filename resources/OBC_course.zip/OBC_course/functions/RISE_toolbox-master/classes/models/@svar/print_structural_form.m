%--- help for svar/print_structural_form ---
%
%  INTERNAL FUNCTION
% 
%