%--- help for generic/initial_conditions ---
%
%  INTERNAL FUNCTION
% 
%