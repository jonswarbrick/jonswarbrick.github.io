%generic is a class.
%    obj = generic(varargin)
%
%    Reference page in Doc Center
%       doc generic
%
%