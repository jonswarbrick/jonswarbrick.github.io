%--- help for generic/fisher ---
%
%  INTERNAL FUNCTION
% 
%