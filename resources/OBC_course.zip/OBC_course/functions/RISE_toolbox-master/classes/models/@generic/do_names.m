%--- help for do_names ---
%
%  INTERNAL FUNCTION
% 
%