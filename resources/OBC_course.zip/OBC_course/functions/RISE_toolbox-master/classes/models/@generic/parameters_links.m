%--- help for generic/parameters_links ---
%
%  INTERNAL FUNCTION
% 
%