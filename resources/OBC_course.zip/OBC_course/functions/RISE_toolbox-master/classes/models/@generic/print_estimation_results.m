%--- help for generic/print_estimation_results ---
%
%  INTERNAL FUNCTION
% 
%