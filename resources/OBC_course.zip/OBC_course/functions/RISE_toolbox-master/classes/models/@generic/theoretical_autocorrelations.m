%--- help for generic/theoretical_autocorrelations ---
%
%  INTERNAL FUNCTION
% 
%