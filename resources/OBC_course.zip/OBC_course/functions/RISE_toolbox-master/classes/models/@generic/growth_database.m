%--- help for generic/growth_database ---
%
%  INTERNAL FUNCTION
% 
%