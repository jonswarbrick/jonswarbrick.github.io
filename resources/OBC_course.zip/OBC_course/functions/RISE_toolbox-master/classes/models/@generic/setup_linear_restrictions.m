%--- help for generic/setup_linear_restrictions ---
%
%  INTERNAL FUNCTION
% 
%