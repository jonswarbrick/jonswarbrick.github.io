%--- help for generic/dbminusdb ---
%
%  INTERNAL FUNCTION
% 
%