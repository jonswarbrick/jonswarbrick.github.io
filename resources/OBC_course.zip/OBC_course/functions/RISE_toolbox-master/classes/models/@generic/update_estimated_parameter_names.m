%--- help for update_estimated_parameter_names ---
%
%  INTERNAL FUNCTION
% 
%