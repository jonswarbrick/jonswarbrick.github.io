%--- help for load_mode ---
%
%  INTERNAL FUNCTION
% 
%