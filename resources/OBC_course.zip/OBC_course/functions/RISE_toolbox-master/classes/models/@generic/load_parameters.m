%--- help for generic/load_parameters ---
%
%  INTERNAL FUNCTION
% 
%