%--- help for get_estimated_parameter_names ---
%
%  INTERNAL FUNCTION
% 
%