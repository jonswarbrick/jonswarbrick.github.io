%--- help for describe_regimes ---
%
%  INTERNAL FUNCTION
% 
%