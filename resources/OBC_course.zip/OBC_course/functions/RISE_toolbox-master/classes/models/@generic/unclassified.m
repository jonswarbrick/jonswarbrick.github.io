%--- help for unclassified ---
%
%  INTERNAL FUNCTION
% 
%