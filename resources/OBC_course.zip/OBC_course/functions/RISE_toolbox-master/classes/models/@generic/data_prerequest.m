%--- help for data_prerequest ---
%
%  INTERNAL FUNCTION
% 
%