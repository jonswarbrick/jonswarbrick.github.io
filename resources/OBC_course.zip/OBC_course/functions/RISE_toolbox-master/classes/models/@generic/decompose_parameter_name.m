%--- help for decompose_parameter_name ---
%
%  INTERNAL FUNCTION
% 
%