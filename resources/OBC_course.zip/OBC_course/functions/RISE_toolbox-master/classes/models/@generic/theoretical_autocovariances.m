%--- help for generic/theoretical_autocovariances ---
%
%  INTERNAL FUNCTION
% 
%  Note:
% 
%     - The variances of the nonstationary variables are automatically set to
%       1. The nonstationary variables are detected by the program when option
%       "solve_bgp" is set to true.
% 
%