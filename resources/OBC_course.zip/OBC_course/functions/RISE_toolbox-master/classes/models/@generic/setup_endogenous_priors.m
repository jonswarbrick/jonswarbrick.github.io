%--- help for generic/setup_endogenous_priors ---
%
%  INTERNAL FUNCTION
% 
%