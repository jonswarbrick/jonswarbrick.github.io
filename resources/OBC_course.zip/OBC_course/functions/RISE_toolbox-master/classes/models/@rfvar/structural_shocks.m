%--- help for rfvar/structural_shocks ---
%
%rfvar/structural_shocks is a function.
%    [s, retcode] = structural_shocks(self, params, Rfunc, shock_names)
%