%--- help for read_identification_restrictions ---
%
%  INTERNAL FUNCTION: Formats identification restrictions
% 
%  See also:
%     :func:`rfvar.identification`
% 
%