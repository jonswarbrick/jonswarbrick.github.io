%--- help for check_property ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named check_property
%
%       dsge/check_property    generic/check_property
%