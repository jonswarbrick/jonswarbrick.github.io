%--- help for dsge/parameterize ---
%
%dsge/parameterize is a function.
%    m = parameterize(m, fcn)
%