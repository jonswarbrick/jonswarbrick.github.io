%--- help for solve_first_order ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named solve_first_order
%
%       dsge/solve_first_order
%