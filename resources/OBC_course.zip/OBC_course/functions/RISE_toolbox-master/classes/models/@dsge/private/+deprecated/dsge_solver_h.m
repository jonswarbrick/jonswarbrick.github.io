%--- help for dsge_solver_h ---
%
%  H1 line
% 
%  ::
% 
% 
%  Args:
% 
%  Returns:
%     :
% 
%  Note:
% 
%  Example:
% 
%     See also:
%
%    Other functions named dsge_solver_h
%
%       dsge/dsge_solver_h
%