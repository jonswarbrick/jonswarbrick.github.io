%--- help for latex_model_file ---
%
%  INTERNAL FUNCTION
% 
%