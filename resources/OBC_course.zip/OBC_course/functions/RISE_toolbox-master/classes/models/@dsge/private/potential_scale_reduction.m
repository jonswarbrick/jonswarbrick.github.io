%--- help for potential_scale_reduction ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named potential_scale_reduction
%
%       dsge/potential_scale_reduction
%