%--- help for dsge_solver_first_order_autoregress_h ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named dsge_solver_first_order_autoregress_h
%
%       dsge/dsge_solver_first_order_autoregress_h
%