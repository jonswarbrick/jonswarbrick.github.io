%--- help for save_filters ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named save_filters
%
%       dsge/save_filters
%