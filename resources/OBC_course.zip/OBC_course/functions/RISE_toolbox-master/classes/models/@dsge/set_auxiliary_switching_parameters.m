%--- help for set_auxiliary_switching_parameters ---
%
%  perturbation_type :
%  - 'm' or 'maih'
%  - 'mw' or 'maih_waggoner'
%  - 'frwz' or {'frwz',part_list} where is a cell array of strings
%