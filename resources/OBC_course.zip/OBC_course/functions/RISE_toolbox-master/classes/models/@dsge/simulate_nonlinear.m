%--- help for dsge/simulate_nonlinear ---
%
%  INTERNAL FUNCTION
% 
%