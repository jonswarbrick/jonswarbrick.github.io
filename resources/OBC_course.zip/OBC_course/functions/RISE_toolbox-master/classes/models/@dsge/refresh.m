% REFRESH Refresh figure.
%    REFRESH causes the current figure window to be redrawn. 
%    REFRESH(FIG) causes the figure FIG to be redrawn.
%
%    Reference page in Doc Center
%       doc refresh
%
%    Other functions named refresh
%
%       dsge/refresh    generic/refresh
%