%--- help for optimal_policy_solver_h ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named optimal_policy_solver_h
%
%       dsge/optimal_policy_solver_h
%