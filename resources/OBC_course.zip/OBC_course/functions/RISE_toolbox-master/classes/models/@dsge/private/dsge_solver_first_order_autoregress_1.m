%--- help for dsge_solver_first_order_autoregress_1 ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named dsge_solver_first_order_autoregress_1
%
%       dsge/dsge_solver_first_order_autoregress_1
%