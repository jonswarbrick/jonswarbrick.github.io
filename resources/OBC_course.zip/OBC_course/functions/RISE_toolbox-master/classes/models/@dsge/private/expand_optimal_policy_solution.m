%--- help for expand_optimal_policy_solution ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named expand_optimal_policy_solution
%
%       dsge/expand_optimal_policy_solution
%