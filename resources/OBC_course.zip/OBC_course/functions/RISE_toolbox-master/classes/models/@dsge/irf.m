%--- help for generic/irf ---
%
%  INTERNAL FUNCTION
%
%    Other functions named irf
%
%       abstvar/irf    dsge/irf
%