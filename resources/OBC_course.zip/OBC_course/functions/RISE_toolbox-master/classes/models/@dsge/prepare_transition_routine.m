%--- help for prepare_transition_routine ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named prepare_transition_routine
%
%       dsge/prepare_transition_routine
%       generic/prepare_transition_routine
%