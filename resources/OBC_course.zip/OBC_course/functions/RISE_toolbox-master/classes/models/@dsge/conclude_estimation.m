%--- help for conclude_estimation ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named conclude_estimation
%
%       dsge/conclude_estimation    generic/conclude_estimation
%