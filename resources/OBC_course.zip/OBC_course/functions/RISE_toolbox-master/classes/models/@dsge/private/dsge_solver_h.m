%--- help for dsge_solver_h ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named dsge_solver_h
%
%       dsge/dsge_solver_h
%