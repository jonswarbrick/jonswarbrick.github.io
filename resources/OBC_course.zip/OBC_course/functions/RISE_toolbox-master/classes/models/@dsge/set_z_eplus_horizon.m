%--- help for set_z_eplus_horizon ---
%
%  INTERNAL FUNCTION
% 
%