%--- help for state_space_wrapper ---
%
%  INTERNAL FUNCTION
% 
%