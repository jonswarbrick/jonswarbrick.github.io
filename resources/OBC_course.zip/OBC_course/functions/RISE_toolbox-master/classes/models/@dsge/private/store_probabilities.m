%--- help for store_probabilities ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named store_probabilities
%
%       dsge/store_probabilities
%