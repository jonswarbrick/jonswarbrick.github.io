%--- help for load_data ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named load_data
%
%       dsge/load_data    generic/load_data
%