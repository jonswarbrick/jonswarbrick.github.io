%--- help for dsge/set_solution_to_companion ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named set_solution_to_companion
%
%       generic/set_solution_to_companion
%