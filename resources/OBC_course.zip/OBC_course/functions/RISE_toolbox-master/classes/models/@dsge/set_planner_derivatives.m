%--- help for set_planner_derivatives ---
%
%  INTERNAL FUNCTION
% 
%