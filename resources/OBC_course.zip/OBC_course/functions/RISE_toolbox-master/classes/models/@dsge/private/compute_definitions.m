%--- help for compute_definitions ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named compute_definitions
%
%       dsge/compute_definitions
%