%--- help for re_order_output_rows ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named re_order_output_rows
%
%       dsge/re_order_output_rows    generic/re_order_output_rows
%