%--- help for format_parameters ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named format_parameters
%
%       dsge/format_parameters
%