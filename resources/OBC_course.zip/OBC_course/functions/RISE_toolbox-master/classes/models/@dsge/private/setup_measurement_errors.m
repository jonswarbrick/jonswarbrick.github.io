%--- help for setup_measurement_errors ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named setup_measurement_errors
%
%       dsge/setup_measurement_errors
%