%--- help for load_solution ---
%
%  INTERNAL FUNCTION
% 
%