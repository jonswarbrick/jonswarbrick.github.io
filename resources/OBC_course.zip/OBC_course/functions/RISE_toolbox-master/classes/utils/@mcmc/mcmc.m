%  mcmc object makes diagnostic plots from mcmc draws
% 
%
%    Reference page in Doc Center
%       doc mcmc
%
%