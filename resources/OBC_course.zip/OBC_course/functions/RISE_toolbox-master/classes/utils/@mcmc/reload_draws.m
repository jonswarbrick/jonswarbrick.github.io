%--- help for mcmc.reload_draws ---
%
%  subset is a 1 x 2 cell array in which
%  - the first cell contains the columns to retain: can be empty, defaults
%  to all
%  - the second column contains the chains to retain: can be empty, defaults
%  to all
%