%--- help for mcmc.process_draws ---
%
%mcmc.process_draws is a function.
%    [d, fd, summary] = process_draws(draws, subset)
%