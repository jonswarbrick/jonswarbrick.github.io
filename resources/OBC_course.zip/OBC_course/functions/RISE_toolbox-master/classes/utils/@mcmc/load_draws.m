%--- help for load_draws ---
%
%  INTERNAL FUNCTION
% 
%