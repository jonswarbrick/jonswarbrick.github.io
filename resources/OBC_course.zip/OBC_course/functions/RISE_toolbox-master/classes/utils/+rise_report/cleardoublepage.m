%  clears double page
% 
%  ::
% 
%     document.clearpage();
% 
%  Args:
%     none
% 
%