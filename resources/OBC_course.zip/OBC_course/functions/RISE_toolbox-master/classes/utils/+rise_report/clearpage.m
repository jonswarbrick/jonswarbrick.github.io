%  clears the page
% 
%  ::
% 
%     document.clearpage();
% 
%  Args:
%     none
% 
%