%  Internal Function -- Not intended to be used by users
% 
%