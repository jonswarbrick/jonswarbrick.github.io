%  Make Quotation
% 
%  ::
% 
%     document.quotation('option_name',option_value);
% 
%  Args:
% 
%     varargin: arguments need to come in pairs
% 
%        - **log** : [char] the quote to insert
%        - **reference** : [char] reference of the quotation
% 
%