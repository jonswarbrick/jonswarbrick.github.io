%  Start a paragraph
% 
%  ::
% 
%     document.paragraph('option_name',option_value);
% 
%  Args:
% 
%     varargin: arguments need to come in pairs
% 
%        - **title** : title of the paragraph
% 
%