%  Internal Object -- Not intended to be used directly by users
% 
%