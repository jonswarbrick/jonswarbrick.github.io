%  Start a new subsection
% 
%  ::
% 
%     document.subsection('option_name',option_value);
% 
%  Args:
% 
%     varargin: arguments need to come in pairs
% 
%        - **title** : title of the subsection
%        - **numbering** : [{true}|false] whether to include the subsection in numbering of the table of contents
% 
%