%  Footnote
% 
%  ::
% 
%     document.footnote('option_name',option_value);
% 
%  Args:
% 
%     varargin: arguments need to come in pairs
% 
%        - **text** : footnote text
% 
%