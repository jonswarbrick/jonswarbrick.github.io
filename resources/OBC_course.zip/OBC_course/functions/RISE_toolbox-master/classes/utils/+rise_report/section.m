%  Start a new section
% 
%  ::
% 
%     document.section('option_name', option_value);
% 
%  Args:
% 
%     varargin: arguments need to come in pairs
% 
%        - **title** : title of the section
%        - **numbering** : [{true}|false] whether to include the section in numbering of the table of contents
% 
%