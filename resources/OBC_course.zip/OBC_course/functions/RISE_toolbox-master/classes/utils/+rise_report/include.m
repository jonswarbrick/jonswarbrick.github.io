%  Insert text from a file
% 
%  ::
% 
%     document.include('option_name',option_value);
% 
%  Args:
% 
%     varargin: arguments need to come in pairs
% 
%        - **filename** : name of the file to be included
% 
%