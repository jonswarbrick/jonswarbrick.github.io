%  Insert a page break
% 
%  ::
% 
%     document.pagebreak();
% 
%  Args:
%     none
% 
%