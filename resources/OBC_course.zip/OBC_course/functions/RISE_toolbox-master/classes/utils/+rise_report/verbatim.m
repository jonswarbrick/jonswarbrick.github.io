%  Insert verbatim (latex verbatim)
% 
%  ::
% 
%     document.verbatim('option_name',option_value);
% 
%  Args:
% 
%     varargin: arguments need to come in pairs
% 
%        - **log** : text of the verbatim
% 
%