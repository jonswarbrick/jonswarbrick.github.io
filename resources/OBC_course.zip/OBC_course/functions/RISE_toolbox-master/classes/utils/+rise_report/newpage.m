%  Create a new page
% 
%  ::
% 
%     document.newpage();
% 
%  Args:
%     none
% 
%