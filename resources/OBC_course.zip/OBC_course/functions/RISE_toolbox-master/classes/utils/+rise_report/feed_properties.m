%  Internal Method
%