%--- help for mdd/cj ---
%
%mdd/cj is a function.
%    [log_mdd, extras] = cj(obj, ~, opts)
%