%--- help for mdd/is ---
%
%  Sylvia Frühwirth-Schnatter (2004): "Estimating marginal
%  likelihoods for mixture and Markov switching models using bridge
%  sampling techniques". Econometrics Journal 7(1) pp 143--167
%