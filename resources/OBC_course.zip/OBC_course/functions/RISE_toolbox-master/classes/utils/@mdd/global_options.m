%--- help for mdd.global_options ---
%
%mdd.global_options is a function.
%    opts = global_options(opts0)
%