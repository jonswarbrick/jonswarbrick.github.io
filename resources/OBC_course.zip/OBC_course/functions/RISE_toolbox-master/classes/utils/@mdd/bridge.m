%--- help for mdd/bridge ---
%
%  Xiao-Li Meng and Wing Hung Wong (1996): " Simulating Ratios of
%  Normalizing Constants via a Simple Identity: A Theoretical
%  Exploration". Statistica Sinica, 6, 831860.
%