%gogetter is a class.
%
%    Reference page in Doc Center
%       doc gogetter
%
%