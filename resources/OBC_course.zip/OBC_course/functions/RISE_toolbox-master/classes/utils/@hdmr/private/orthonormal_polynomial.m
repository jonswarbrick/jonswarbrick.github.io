%--- help for orthonormal_polynomial ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named orthonormal_polynomial
%
%       hdmr/orthonormal_polynomial
%