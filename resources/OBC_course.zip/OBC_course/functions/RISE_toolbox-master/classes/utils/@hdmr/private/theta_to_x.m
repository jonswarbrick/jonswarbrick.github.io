%--- help for theta_to_x ---
%
%  INTERNAL FUNCTION
% 
%
%    Other functions named theta_to_x
%
%       hdmr/theta_to_x
%