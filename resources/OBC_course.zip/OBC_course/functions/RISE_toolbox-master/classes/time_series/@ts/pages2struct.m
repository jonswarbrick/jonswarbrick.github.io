%  INTERNAL FUNCTION: this function is a decoy
% 
%
%    Other functions named pages2struct
%
%       ts/pages2struct
%