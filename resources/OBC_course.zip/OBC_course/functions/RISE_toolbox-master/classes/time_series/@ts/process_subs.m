%--- help for process_subs ---
%
%  H1 line
% 
%  ::
% 
% 
%  Args:
% 
%  Returns:
%     :
% 
%  Note:
% 
%  Example:
% 
%     See also:
%