%--- help for unary_operation ---
%
%  H1 line
% 
%  ::
% 
% 
%  Args:
% 
%  Returns:
%     :
% 
%  Note:
% 
%  Example:
% 
%     See also:
%