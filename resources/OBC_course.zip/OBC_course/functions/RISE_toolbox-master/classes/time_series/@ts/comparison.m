%--- help for comparison ---
%
%  INTERNAL FUNCTION
% 
%