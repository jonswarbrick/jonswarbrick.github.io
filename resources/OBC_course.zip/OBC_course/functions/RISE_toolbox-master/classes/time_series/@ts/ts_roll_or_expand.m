%--- help for ts_roll_or_expand ---
%
%  H1 line
% 
%  ::
% 
% 
%  Args:
% 
%  Returns:
%     :
% 
%  Note:
% 
%  Example:
% 
%     See also:
%