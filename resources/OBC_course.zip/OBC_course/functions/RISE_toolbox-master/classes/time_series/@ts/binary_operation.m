%--- help for binary_operation ---
%
%  INTERNAL FUNCTION
% 
%