%--- help for ts/apply ---
%
%  INTERNAL FUNCTION
% 
%