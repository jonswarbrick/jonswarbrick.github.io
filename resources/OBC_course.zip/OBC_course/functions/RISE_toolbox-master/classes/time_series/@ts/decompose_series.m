%--- help for decompose_series ---
%
%  INTERNAL FUNCTION
% 
%