%  applies a basic operation to a ts object or a structure of ts objects.
%  e.g.
%  - db=tsapply(db,'log')
%  - db=tsapply(db,@log)
%  - db=tsapply(db,@(x)100*x)
%